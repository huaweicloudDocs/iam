# Token管理<a name="iam_30_0000"></a>

-   **[获取IAM用户Token（使用密码）](获取IAM用户Token（使用密码）.md)**  

-   **[获取IAM用户Token（使用密码+虚拟MFA）](获取IAM用户Token（使用密码+虚拟MFA）.md)**  

-   **[获取委托Token](获取委托Token.md)**  

-   **[校验Token的有效性](校验Token的有效性.md)**  


