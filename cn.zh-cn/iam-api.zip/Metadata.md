# Metadata<a name="iam_13_0501"></a>

-   **[查询Metadata文件](查询Metadata文件.md)**  

-   **[查询Keystone的Metadata文件](查询Keystone的Metadata文件.md)**  

-   **[导入Metadata文件](导入Metadata文件.md)**  


