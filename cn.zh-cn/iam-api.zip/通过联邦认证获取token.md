# 通过联邦认证获取token<a name="iam_13_0003"></a>

-   **[SP initiated方式](SP-initiated方式.md)**  

-   **[IdP initiated方式](IdP-initiated方式.md)**  


