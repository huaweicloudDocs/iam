# Token<a name="iam_13_0601"></a>

-   **[获取联邦认证unscoped token\(SP initiated\)](获取联邦认证unscoped-token(SP-initiated).md)**  

-   **[获取联邦认证unscoped token\(IdP initiated\)](获取联邦认证unscoped-token(IdP-initiated).md)**  

-   **[获取联邦认证scoped token](获取联邦认证scoped-token.md)**  

-   **[获取联邦认证token\(OpenID Connect ID token方式\)](获取联邦认证token(OpenID-Connect-ID-token方式).md)**  

-   **[获取联邦认证unscoped token\(OpenID Connect ID token方式\)](获取联邦认证unscoped-token(OpenID-Connect-ID-token方式).md)**  


